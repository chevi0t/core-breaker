潮路搬送区の斜め高架・B–C遮蔽版。v6/replay/replay.htmlをブラウザで開く。v5は同seedの変更前。図面と実景も同梱。各4戦の詳細はv6/README.md参照。
